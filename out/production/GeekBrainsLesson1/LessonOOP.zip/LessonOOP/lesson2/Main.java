package LessonOOP.lesson2;

public class Main {
    public static void main(String[] args) {
        Dog dog1 = new Dog();
        Animal cat1 = new Cat();

        dog1.run(150);
        cat1.run(5000);

        dog1.jump(10);
        cat1.jump(11);

        dog1.swim(3);
        cat1.swim(3);
    }
}