package LessonOOP.lesson2;
//(бег: кот – 200 м., собака – 500 м.; прыжок: кот – 2 м.,
//// собака – 0.5 м.; плавание: кот не умеет плавать, собака – 10 м.);
class Cat extends Animal {
    @Override
    void swim(int length) {
        boolean result = false;
        showResult(this,result);
    }
    @Override
    void run(int length) {
        boolean result = length <= 200;
        if (result) _length = length;
        showResult(this,result);
    }
    @Override
    void jump(double height) {
        boolean result = height <= 2;
        if (result) _height = height;
        showResult(this,result);
    }

}
